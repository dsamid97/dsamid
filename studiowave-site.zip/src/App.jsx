export default function App() {
  return (
    <div style={{fontFamily: 'sans-serif', padding: '60px', textAlign:'center'}}>
      <h1 style={{fontSize:'48px', fontWeight:700}}>Studio Wave</h1>
      <p style={{fontSize:'20px', maxWidth:'600px', margin:'20px auto'}}>
        Website structure is ready. The detailed landing content from the canvas version
        will be integrated in the next step (UI styling + Tailwind).
      </p>
    </div>
  )
}
